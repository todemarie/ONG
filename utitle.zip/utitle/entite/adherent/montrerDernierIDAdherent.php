<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$sql = "SELECT MAX(IDAdherent) FROM adherent";
	$stmt = $conn->prepare($sql);
	$stmt->execute();
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	
	echo $row['MAX(IDAdherent)'];
	$stmt->closeCursor();
?>