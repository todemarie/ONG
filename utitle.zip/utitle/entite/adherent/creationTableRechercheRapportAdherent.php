<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$rechercheDetailsAdherentSql = 'SELECT * FROM adherent';
	$rechercheDetailsAdherentStatement = $conn->prepare($rechercheDetailsAdherentSql);
	$rechercheDetailsAdherentStatement->execute();
	
	$output = '<table id="tableDetailsAdherent" class="table table-sm table-striped table-bordered table-hover" style="width:100%">
				<thead>
					<tr>
						<th>ID Adherent</th>
						<th>Immatriculation</th>
						<th>Nom Adherent</th>
						<th>Ville</th>
						<th>Prenoms</th>
						<th>N° CNI/ATT/PASSPORT</th>
						<th>Tel</th>
						<th>Quartier</th>
					</tr>
				</thead>
				<tbody>';
	
	// Crée des lignes de tableau à partir des données sélectionnées
	while($row = $rechercheDetailsAdherentStatement->fetch(PDO::FETCH_ASSOC)){
		
		$output .= '<tr>' .
						'<td>' . $row['IDAdherent'] . '</td>' .
						'<td>' . $row['immatriculationAdherent'] . '</td>' .
						'<td><a href="#" class="detailsAdherentHover" data-toggle="popover" id="' . $row['IDAdherent'] . '">' . $row['nomAdherent'] . '</a></td>' .
						'<td>' . $row['villeAdherent'] . '</td>' .
						'<td>' . $row['prenomAdherent'] . '</td>' .
						'<td>' . $row['cniAdherent'] . '</td>' .
						'<td>' . $row['telAdherent'] . '</td>' .
						'<td>' . $row['quartierAdherent'] . '</td>' .
					'</tr>';
	}
	
	$rechercheDetailsAdherentStatement->closeCursor();
	
	$output .= '</tbody>
					<tfoot>
						<tr>
						<th>ID Adherent</th>
						<th>Immatriculation</th>
						<th>Nom Adherent</th>
						<th>Ville</th>
						<th>Prenoms</th>
						<th>N° CNI/ATT/PASSPORT</th>
						<th>Tel</th>
						<th>Quartier</th>
						</tr>
					</tfoot>
				</table>';
	echo $output;
?>