<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	if(isset($_POST['id'])){
		
		$IDAdherent = htmlentities($_POST['id']);
		
		
	// Récupère tous les détails de l'adherent
		$sql = 'SELECT * FROM adherent WHERE IDAdherent = :IDAdherent';
		$stmt = $conn->prepare($sql);
		$stmt->execute(['IDAdherent' => $IDAdherent]);
		
		
		
		echo "";
	}
?>