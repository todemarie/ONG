<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	
	
	if(isset($_POST['detailsAdherentImmatriculationAdherent'])){
		
		$immatriculationAdherent = htmlentities($_POST['detailsAdherentImmatriculationAdherent']);
		$nomAdherent = htmlentities($_POST['detailsAdherentNomAdherent']);
		$villeAdherent = htmlentities($_POST['detailsAdherentVilleAdherent']);
		$prenomAdherent = htmlentities($_POST['detailsAdherentPrenomAdherent']);
		$cniAdherent = htmlentities($_POST['detailsAdherentCniAdherent']);
		$telAdherent = htmlentities($_POST['detailsAdherentTelAdherent']);
		$quartierAdherent = htmlentities($_POST['detailsAdherentQuartierAdherent']);

		
		
		// Vérifie si les champs obligatoires ne sont pas vides
		if(!empty($immatriculationAdherent) && !empty($nomAdherent) && isset($cniAdherent) && isset($telAdherent) && isset($villeAdherent)){
			
			// Assainir le numéro d'adherent
			$immatriculationAdherent = filter_var($immatriculationAdherent, FILTER_SANITIZE_STRING);
			
			
			// Vérifie si le nom complet est vide ou non
			if($nomAdherent == ''){
				// Le nom complet est vide
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Veuillez entrer le nom correct.</div>';
				exit();
			}
			
			// Valider le numéro de tel
			if(filter_var($telAdherent, FILTER_VALIDATE_INT) === 0 || filter_var($telAdherent, FILTER_VALIDATE_INT)) {
				// Numéro de portable valide
			} else {
				// Mobile is wrong
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>s il vous plaît entrer un numéro de téléphone valide</div>';
				exit();
			}

			// Valider la ville
			if($villeAdherent == ''){
				// La ville est vide
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Veuillez entrer lA VILLE 1</div>';
				exit();
			}
			 


				// l'élément n'existe pas, vous pouvez donc l'ajouter à la base de données en tant que nouvel élément
// Démarre le processus d'insertion
				$insererAdherentSql = 'INSERT iNTO adherent(immatriculationAdherent, nomAdherent , villeAdherent, prenomAdherent, cniAdherent, telAdherent, quartierAdherent) VALUES(:immatriculationAdherent, :nomAdherent, :villeAdherent, :prenomAdherent, :cniAdherent, :telAdherent, :quartierAdherent)';
				$insererAdherentStatement = $conn->prepare($insererAdherentSql);
				$insererAdherentStatement->execute(['immatriculationAdherent' => $immatriculationAdherent, 'nomAdherent' => $nomAdherent, 'villeAdherent' => $villeAdherent, 'prenomAdherent' => $prenomAdherent, 'cniAdherent' => $cniAdherent, 'telAdherent' => $telAdherent, 'quartierAdherent' => $quartierAdherent]);
				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>adherant enregistré .</div>';
				exit();
			

		} else {
			// Un ou plusieurs champs obligatoires sont vides. Par conséquent, affichez un message d'erreur
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Veuillez renseigner tous les champs marqués d un (*)</div>';
			exit();
		}
	}
?>