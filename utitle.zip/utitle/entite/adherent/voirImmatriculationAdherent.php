<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	// Vérifie si la requête POST est reçue et si oui, exécute le script
	if(isset($_POST['textBoxValue'])){
		$output = '';
		$immatriculationAdherentString = '%' . htmlentities($_POST['textBoxValue']) . '%';
		
		// Construction de la requête SQL pour obtenir l'immatriculation de l'élément
		$sql = 'SELECT immatriculationAdherent FROM adherent WHERE immatriculationAdherent LIKE ?';
		$stmt = $conn->prepare($sql);
		$stmt->execute([$immatriculationAdherentString]);
		
		// Si nous recevons des résultats de la requête ci-dessus, affichez-les dans une liste
		if($stmt->rowCount() > 0){
			$output = '<ul class="list-unstyled suggestionsList" id="detailsAdherentImmatriculationAdherentSuggestionsList">';
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$output .= '<li>' . $row['immatriculationAdherent'] . '</li>';
			}
			echo '</ul>';
		} else {
			$output = '';
		}
		$stmt->closeCursor();
		echo $output;
	}
?>