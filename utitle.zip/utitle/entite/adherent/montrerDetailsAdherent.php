<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');

	// Exécute le script si la requête POST est soumise
	if(isset($_POST['immatriculationAdherent'])){
		
		$immatriculationAdherent = htmlentities($_POST['immatriculationAdherent']);
		
		$detailsAdherentSql = 'SELECT * FROM adherent WHERE immatriculationAdherent = :immatriculationAdherent';
		$detailsAdherentStatement = $conn->prepare($detailsAdherentSql);
		$detailsAdherentStatement->execute(['immatriculationAdherent' => $immatriculationAdherent]);
		
		// Si des données sont trouvées pour le numéro d'immatriculation donné, retournez-les en tant qu'objet json
		if($detailsAdherentStatement->rowCount() > 0) {
			$row = $detailsAdherentStatement->fetch(PDO::FETCH_ASSOC);
			echo json_encode($row);
		}
		$detailsAdherentStatement->closeCursor();
	}
?>