<?php
	$detailsAdherentSql = 'SELECT * FROM adherent';
	$detailsAdherentStatement = $conn->prepare($detailsAdherentSql);
	$detailsAdherentStatement->execute();
	
	if($detailsAdherentStatement->rowCount() > 0) {
		while($row = $detailsAdherentStatement->fetch(PDO::FETCH_ASSOC)) {
			echo '<option>' . $row['nomAdherent'] . '</option>';
		}
	}
	$detailsAdherentStatement->closeCursor();
?>