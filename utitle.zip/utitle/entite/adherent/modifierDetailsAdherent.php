<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	// Vérifie si la requête POST est reçue
	if(isset($_POST['detailsAdherentImmatriculationAdherent'])) {

		
		$detailsAdherentImmatriculationAdherent = htmlentities($_POST['detailsAdherentImmatriculationAdherent']);
		$detailsAdherentNomAdherent = htmlentities($_POST['detailsAdherentNomAdherent']);
		$detailsAdherentVilleAdherent = htmlentities($_POST['detailsAdherentVilleAdherent']);
		$detailsAdherentPrenomAdherent = htmlentities($_POST['detailsAdherentPrenomAdherent']);
		$detailsAdherentCniAdherent = htmlentities($_POST['detailsAdherentCniAdherent']);
		$detailsAdherentTelAdherent = htmlentities($_POST['detailsAdherentTelAdherent']);
		$detailsAdherentQuartierAdherent = htmlentities($_POST['detailsAdherentQuartierAdherent']);
		
		
		
		// Vérifie si les champs obligatoires ne sont pas vides
		if(!empty($detailsAdherentImmatriculationAdherent) && !empty($detailsAdherentNomAdherent)  && isset($detailsAdherentTelAdherent)){
			
			// Assainir le numéro d immatriculation
			$detailsAdherentImmatriculationAdherent = filter_var($detailsAdherentImmatriculationAdherent, FILTER_SANITIZE_STRING);
			
			// Valider le numero de tel
			if(filter_var($detailsAdherentTelAdherent, FILTER_VALIDATE_INT) === 0 || filter_var($detailsAdherentTelAdherent, FILTER_VALIDATE_INT)) {
				// Le numéro de mobile est valide
			} else {
				// Le numéro de tel n'est pas valide
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Veuillez entrer un numéro de portable valide</div>';
				exit();
			}
			
			
			
			// Vérifie si l'immatriculation donné est dans la DB
			$immatriculationAdherentSelectSql = 'SELECT immatriculationAdherent FROM adherent WHERE immatriculationAdherent = :immatriculationAdherent';
			$immatriculationAdherentSelectStatement = $conn->prepare($immatriculationAdherentSelectSql);
			$immatriculationAdherentSelectStatement->execute(['immatriculationAdherent' => $detailsAdherentImmatriculationAdherent]);
				
			if($immatriculationAdherentSelectStatement->rowCount() > 0) {
		
			// Construire la requête du modificateur
			$modifierDetailsAdherentSql = 'UPDATE adherent SET nomAdherent = :nomAdherent, villeAdherent = :villeAdherent, prenomAdherent = :prenomAdherent , cniAdherent = :cniAdherent, telAdherent = :telAdherent, quartierAdherent = :quartierAdherent WHERE immatriculationAdherent = :immatriculationAdherent';
			$modifierDetailsAdherentStatement = $conn->prepare($modifierDetailsAdherentSql);
			$modifierDetailsAdherentStatement->execute(['nomAdherent' => $detailsAdherentNomAdherent, 'villeAdherent' => $detailsAdherentVilleAdherent, 'prenomAdherent' => $detailsAdherentPrenomAdherent, 'cniAdherent' =>$detailsAdherentCniAdherent, 'telAdherent' => $detailsAdherentTelAdherent, 'quartierAdherent' => $detailsAdherentQuartierAdherent, 'immatriculationAdherent' => $detailsAdherentImmatriculationAdherent]);
			
			echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Détails de l adhérant mis à jour.</div>';
				exit();
			
			
			} else {
				// immatriculation Adherent n'est pas dans DB. Par conséquent, arrêtez la mise à jour et quittez
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>ID Adherant n existe pas dans DB. Par conséquent, mise à jour impossible.</div>';
				exit();
			}
			
		} else {
			// Un ou plusieurs champs obligatoires sont vides. Par conséquent, affichez le message d'erreur
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Veuillez renseigner tous les champs marqués d un (*)</div>';
			exit();
		}
	}
?>