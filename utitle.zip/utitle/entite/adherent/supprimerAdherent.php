<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$immatriculationAdherent = htmlentities($_POST['detailsAdherentImmatriculationAdherent']);
	
	if(isset($_POST['detailsAdherentImmatriculationAdherent'])){
		
		// Vérifie si les champs obligatoires ne sont pas vides
		if(!empty($immatriculationAdherent)){
			
			// Assainir le numéro d'immatriculation
			$immatriculationAdherent = filter_var($immatriculationAdherent, FILTER_SANITIZE_STRING);

			// Vérifie si l'élément est dans la base de données
			$adherentSql = 'SELECT immatriculationAdherent FROM adherent WHERE immatriculationAdherent=:immatriculationAdherent';
			$adherentStatement = $conn->prepare($adherentSql);
			$adherentStatement->execute(['immatriculationAdherent' => $immatriculationAdherent]);
			
			if($adherentStatement->rowCount() > 0){
				
				// L'élément existe dans la base de données. Commencez donc le processus de suppression
				$supprimerAdherentSql = 'DELETE FROM adherent WHERE immatriculationAdherent=:immatriculationAdherent';
				$supprimerAdherentStatement = $conn->prepare($supprimerAdherentSql);
				$supprimerAdherentStatement->execute(['immatriculationAdherent' => $immatriculationAdherent]);

				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Adherant supprimé.</div>';
				exit();
				
			} else {
				// L'élément n'existe pas, par conséquent, indiquez à l'utilisateur qu'il ne peut pas supprimer cet élément
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Le matricule n existe pas ! Donc ne peut être supprimé </div>';
				exit();
			}
			
		} else {
			// Le numéro d'article est vide. Par conséquent, affichez le message d'erreur
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button> Entrer le code svp</div>';
			exit();
		}
	}
?>