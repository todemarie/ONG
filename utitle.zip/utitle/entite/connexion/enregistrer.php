<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$enregistrerNom = '';
	$enregistrerPseudo = '';
	$enregistrerMdp1 = '';
	$enregistrerMdp2 = '';
	$hashedMdp = '';
	
	if(isset($_POST['enregistrerPseudo'])){
		$enregistrerNom = htmlentities($_POST['enregistrerNom']);
		$enregistrerPseudo = htmlentities($_POST['enregistrerPseudo']);
		$enregistrerMdp1 = htmlentities($_POST['enregistrerMdp1']);
		$enregistrerMdp2 = htmlentities($_POST['enregistrerMdp2']);
		
		if(!empty($enregistrerNom) && !empty($enregistrerPseudo) && !empty($enregistrerMdp1) && !empty($enregistrerMdp2)){
			
			// Nettoyer le nom
			$enregistrerNom = filter_var($enregistrerNom, FILTER_SANITIZE_STRING);
			
			// Verifier si le nom est vide
			if($enregistrerNom == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Saisissez votre nom svp.</div>';
				exit();
			}
			
			// Verifier si le pseudo est vide
			if($enregistrerPseudo == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Saisissez votre pseudo svp.</div>';
				exit();
			}
			
			// Verifier si les mots de passe est vide
			if($enregistrerMdp1 == '' || $enregistrerMdp2 == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Saisissez les deux mots de passe.</div>';
				exit();
			}
			
			// Verifier si le pseudo est valide
			$verificationPseudoSql = 'SELECT * FROM utilisateur WHERE pseudo = :pseudo';
			$verificationPseudoStatement = $conn->prepare($verificationPseudoSql);
			$verificationPseudoStatement->execute(['pseudo' => $enregistrerPseudo]);
			
			if($verificationPseudoStatement->rowCount() > 0){
				//Le pseudo existe déjà. 
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>pseudo non valide. Svp entrer un different pseudo.</div>';
				exit();
			} else {
				// Verifier si les mots de passe est vide
				if($enregistrerMdp1 !== $enregistrerMdp2){
					echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Les mots de passe ne correspondent pas.</div>';
					exit();
				} else {
					// Commencer à insérer l'utilisateur dans la BD
// Crypte le motdepasse
					$hashedMdp = md5($enregistrerMdp1);
					$insererUtilisteurSql = 'INSERT INTO utilisateur(nomutilisateur, pseudo, motdepasse) VALUES(:nomutilisateur, :pseudo, :motdepasse)';
					$insererUtilisteurStatement = $conn->prepare($insererUtilisteurSql);
					$insererUtilisteurStatement->execute(['nomutilisateur' => $enregistrerNom, 'pseudo' => $enregistrerPseudo, 'motdepasse' => $hashedMdp]);
					
					echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Enregistré avec succès .</div>';
					exit();
				}
			}
		} else {
			// Un ou plusieurs champs obligatoires sont vides. Par conséquent, affichez un message d'erreur
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Remplir tout les champs marqués de (*)</div>';
			exit();
		}
	}
?>