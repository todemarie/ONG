<?php
	session_start();
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$connecterPseudo = '';
	$connecterMdp = '';
	$hashedMdp = '';
	
	if(isset($_POST['connecterPseudo'])){
		$connecterPseudo = $_POST['connecterPseudo'];
		$connecterMdp = $_POST['connecterMdp'];
		
		if(!empty($connecterPseudo) && !empty($connecterPseudo)){
			
			// Nettoyer pseudo
			$connecterPseudo = filter_var($connecterPseudo, FILTER_SANITIZE_STRING);
			
			// Verifier si pseudo est vide
			if($connecterPseudo == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Entrer votre pseudo</div>';
				exit();
			}
			
			// Verifier si motdepasse est vide
			if($connecterMdp == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Entrer votre mot de passe</div>';
				exit();
			}
			
			// Encrypt the motdepasse
			$hashedMdp = md5($connecterMdp); 
			
			// Check the given credentials
			$verifierUtilisateurSql = 'SELECT * FROM utilisateur WHERE pseudo = :pseudo AND motdepasse = :motdepasse'; 
			$verifierUtilisateurStatement = $conn->prepare($verifierUtilisateurSql);
			$verifierUtilisateurStatement->execute(['pseudo' => $connecterPseudo, 'motdepasse' => $hashedMdp]);
			
			// Vérifie si l'utilisateur existe ou non
			if($verifierUtilisateurStatement->rowCount() > 0){
				// Identifiants valides. Par conséquent, démarrez la session
				$row = $verifierUtilisateurStatement->fetch(PDO::FETCH_ASSOC);

				$_SESSION['loggedIn'] = '1';
				$_SESSION['nomutilisateur'] = $row['nomutilisateur'];
				
				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Connexion réussie! Actualisez la page</div>';
				exit();
			} else {
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button> pseudo / mot de passe incorrecte</div>';
				exit();
			}
			
			
		} else {
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Entrer votre pseudo et mot de passe</div>';
			exit();
		}
	}
?>