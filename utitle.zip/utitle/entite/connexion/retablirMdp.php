<?php
	require_once('../../connexions/config/constants.php');
	require_once('../../connexions/config/db.php');
	
	$retablirMdpPseudo = '';
	$retablirMdpMdp1 = '';
	$retablirMdpMdp2 = '';
	$hashedMdp = '';
	
	if(isset($_POST['retablirMdpPseudo'])){
		$retablirMdpPseudo = htmlentities($_POST['retablirMdpPseudo']);
		$retablirMdpMdp1 = htmlentities($_POST['retablirMdpMdp1']);
		$retablirMdpMdp2 = htmlentities($_POST['retablirMdpMdp2']);
		
		if(!empty($retablirMdpPseudo) && !empty($retablirMdpMdp1) && !empty($retablirMdpMdp2)){
			
			// Verifier si pseudo est vide
			if($retablirMdpPseudo == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Saisissez votre pseudo svp.</div>';
				exit();
			}
			
			// Verifier si pseudo est vide
			if($retablirMdpMdp1 == '' || $retablirMdpMdp2 == ''){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Entrer les deux mots de passe.</div>';
				exit();
			}
			
			// verifier si pseudo est valide
			$verifierpseudoSql = 'SELECT * FROM utilisateur WHERE pseudo = :pseudo';
			$verifierpseudoStatement = $conn->prepare($verifierpseudoSql);
			$verifierpseudoStatement->execute(['pseudo' => $retablirMdpPseudo]);
			
			if($verifierpseudoStatement->rowCount() < 1){
				// pseudo doesn't exist. Hence can't reset password
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>pseudo n existe pas.</div>';
				exit();
			} else {
				// Verufier si ls mots de passe sont egaux
				if($retablirMdpMdp1 !== $retablirMdpMdp2){
					echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Les mots de passe ne correspondent pas.</div>';
					exit();
				} else {
					/// Commencer à insérer l'utilisateur dans la BD
// Crypte le motdepasse
					$hashedMdp = md5($retablirMdpMdp1);
					$mettreajourSql = 'UPDATE utilisateur SET motdepasse = :motdepasse WHERE pseudo = :pseudo';
					$mettreajourStatement = $conn->prepare($mettreajourSql);
					$mettreajourStatement->execute(['motdepasse' => $hashedMdp, 'pseudo' => $retablirMdpPseudo]);
					
					echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Mot de passe retabli.Connectez-vous avec votre nouveau mot de passe.</div>';
					exit();
				}
			}
		} else {
			// Un ou plusieurs champs obligatoires sont vides. Par conséquent, affichez un message d'erreur
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Remplir tout les champs marqués de (*)</div>';
			exit();
		}
	}
?>