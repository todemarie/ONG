<?php
	session_start();
	
	unset($_SESSION['loggedIn']);
	unset($_SESSION['nomutilisateur']);
	session_destroy();
	header('Location: ../../connexion.php');
	exit();
?>