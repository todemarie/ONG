    <!-- Footer -->
    <footer class="footer bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; ONG Adhesion <?php echo date('Y'); ?></p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="design/jquery/jquery.min.js"></script>
    <script src="design/bootstrap/js/bootstrap.bundle.min.js"></script>
	
	<!-- Datatables script -->
	<script type="text/javascript" charset="utf8" src="design/DataTables/datatables.js"></script>
	<script type="text/javascript" charset="utf8" src="design/DataTables/sumsum.js"></script>
	
	<!-- Chosen files for select boxes -->
	<script src="design/chosen/chosen.jquery.min.js"></script>
	<link rel="stylesheet" href="design/chosen/chosen.css" />
	
	<!-- Datepicker JS -->
	<script src="design/datepicker164/js/bootstrap-datepicker.min.js"></script>
	
	<!-- Bootbox JS -->
	<script src="design/bootbox/bootbox.min.js"></script>
	
	<!-- Custom scripts -->
	<script src="css&js/js/scripts.js"></script>
	<script src="css&js/js/connexion.js"></script>