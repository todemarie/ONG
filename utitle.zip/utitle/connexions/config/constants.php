<?php
	// Root url for the site
	define('ROOT_URL', 'http://localhost/cifef_adhesion/');
	
	
	// Database parameters
	// Data source name
	define('DSN', 'mysql:host=localhost;dbname=basededonnee');
	
	// Hostname
	define('DB_HOST', 'localhost');
	
	// DB user
	define('DB_USER', 'marie');
	
	// DB password
	define('DB_PASSWORD', 'toderachel');
	
	// DB name
	define('DB_NAME', 'basededonnee');
?>