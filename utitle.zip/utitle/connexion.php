<?php
	session_start();
	
	// Vérifie si l'utilisateur est déjà connecté
	if(isset($_SESSION['loggedIn'])){
		header('Location:index.php');
		exit();
	}
	
	require_once('connexions/config/constants.php');
	require_once('connexions/config/db.php');
	require_once('connexions/entete.html');
	?>
	<body>
  
  <?php
  // Variable pour stocker l'action (CONNEXION, ENREGISTRER, RETABLIRMDP)
  $action = '';
	  if(isset($_GET['action'])){
		  $action = $_GET['action'];
		  if($action == 'enregistrer'){
  ?>
			  <div class="container">
				<div class="row justify-content-center">
				<div class="col-sm-12 col-md-6 col-lg-6">
				  <div class="card">
					<div class="card-header">
					  Inscription 
					</div>
					<div class="card-body">
					  <form action="">
					  <div id="enregistrerMessage"></div>
						<div class="form-group">
						  <label for="enregistrerNom">Nom Utilisateur<span class="requiredIcon">*</span></label>
						  <input type="text" class="form-control" placeholder="Nom utilisateur"  id="enregistrerNom" placeholder="<i>Mot de passe</i>" name="enregistrerNom">
						  <!-- <small id="emailHelp" class="form-text text-muted"></small> -->
						</div>
						 <div class="form-group">
						  <label for="enregistrerPseudo">Pseudo<span class="requiredIcon">*</span></label>
						  <input type="email" class="form-control" placeholder="Pseudo" id="enregistrerPseudo" placeholder="<i>Speudo</i>" name="enregistrerPseudo" autocomplete="on">
						</div>
						<div class="form-group">
						  <label for="enregistrerMdp1">Mot de passe<span class="requiredIcon">*</span></label>
						  <input type="password" placeholder="Mot de passe" class="form-control" id="enregistrerMdp1" placeholder="<i>Mot de passe</i>" name="enregistrerMdp1">
						</div>
						<div class="form-group">
						  <label for="enregistrerMdp2">Re-saississez le mot de passe<span class="requiredIcon">*</span></label>
						  <input type="password" placeholder="Mot de passe" class="form-control" id="enregistrerMdp2" name="enregistrerMdp2" placeholder="<i>Mot de passe</i>">
						</div>
						<a href="connexion.php" class="btn btn-primary">Se connecter</a>
						<button type="button" id="enregistrer" class="btn btn-success">S'inscrire</button>
						<a href="connexion.php?action=retablirMdp" class="btn btn-warning">Changer mot de passe</a>
						<button type="reset" class="btn">Effacer</button>
					  </form>
					</div>
				  </div>
				  </div>
				</div>
			  </div>
  <?php
			  require 'connexions/piedpage.php';
			  echo '</body></html>';
			  exit();
		  } elseif($action == 'retablirMdp'){
  ?>
			  <div class="container">
				<div class="row justify-content-center">
				<div class="col-sm-12 col-md-6 col-lg-6">
				  <div class="card">
					<div class="card-header">
					  Changer le Mot de passe
					</div>
					<div class="card-body">
					  <form action="">
					  <div id="messageRetablirMdp"></div>
						<div class="form-group">
						  <label for="retablirMdpPseudo">Pseudo<span class ="requiredIcon">*</span></label>
						  <input type="text" class="form-control" id="retablirMdpPseudo" placeholder="Pseudo" name="retablirMdpPseudo">
						</div>
						<div class="form-group">
						  <label for="retablirMdpMdp1">Nouveau mot de passe<span class ="requiredIcon">*</span></label>
						  <input type="password" class="form-control" placeholder="Nouveau Mot de passe" id="retablirMdpMdp1" name="retablirMdpMdp1">
						</div>
						<div class="form-group">
						  <label for="retablirMdpMdp2">Confirmez Nouveau Mot de passe<span class ="requiredIcon">*</span></label>
						  <input type="password" class="form-control" id="retablirMdpMdp2" placeholder="Nouveau Mot de passe" name="retablirMdpMdp2">
						</div>
						<a href="connexion.php" class="btn btn-primary">Se connecter</a>
						<a href="connexion.php?action=enregistrer" class="btn btn-success">S'inscrire</a>
						<button type="button" id="boutonRetablirMdp" class="btn btn-warning">Changer Mot de passe</button>
						<button type="reset" class="btn">Effacer</button>
					  </form>
					</div>
				  </div>
				  </div>
				</div>
			  </div>
  <?php
			  require 'connexions/piedpage.php';
			  echo '</body></html>';
			  exit();
		  }
	  }	
  ?>
	  <!-- Contenu de la page par défaut (formulaire de connexion) -->
	  <div class="container">
		<div class="row justify-content-center">
		<div class="col-sm-12 col-md-6 col-lg-6">
		  <div class="card">
			<div class="card-header">
			  Connexion
			</div>
			<div class="card-body">
			  <form action="">
			  <div id="messageConnexion"></div>
				<div class="form-group">
				  <label for="connecterPseudo">Pseudo</label>
				  <input type="text" class="form-control" id="connecterPseudo" placeholder="Pseudo" name="connecterPseudo">
				</div>
				<div class="form-group">
				  <label for="connecterMdp">Mot de passe</label>
				  <input type="password" class="form-control" id="connecterMdp" placeholder="Mot de passe" name="connecterMdp">
				</div>
				<button type="button" id="connexion" class="btn btn-primary">Se connecter</button>
				<a href="connexion.php?action=enregistrer" class="btn btn-success">S'inscrire</a>
				<a href="connexion.php?action=retablirMdp" class="btn btn-warning">Changer Mot de passe</a>
				<button type="reset" class="btn">Effacer</button>
			  </form>
			</div>
		  </div>
		  </div>
		</div>
	  </div>
  <?php
	   require('connexions/piedpage.php')
  ?>
	</body>
  </html>
  