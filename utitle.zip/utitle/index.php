<?php
	session_start();
	// Redirige l'utilisateur vers la page de connexion s'il n'est pas connecté.
	if(!isset($_SESSION['loggedIn'])){
		header('Location:connexion.php');
		exit();
	}
	
	require_once('connexions/config/constants.php');
	require_once('connexions/config/db.php');
	require_once('connexions/entete.html');
?>
  <body>
<?php
	require 'connexions/navigation.php';
?>
    <!-- Contenu de la page -->
    <div class="container-fluid">
	  <div class="row">
		<div class="col-lg-2">
		<h1 class="my-4"></h1>
			<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
			  <a class="nav-link active" id="v-pills-adherent-tab" data-toggle="pill" href="#v-pills-adherent" role="tab" aria-controls="v-pills-adherent" aria-selected="true">Adherant</a>
			  <a class="nav-link" id="v-pills-recherche-tab" data-toggle="pill" href="#v-pills-recherche" role="tab" aria-controls="v-pills-recherche" aria-selected="false">Recherche</a>

			</div>
		</div>
		 <div class="col-lg-9">
			<div class="tab-content" id="v-pills-tabContent">
			  <div class="tab-pane fade show active" id="v-pills-adherent" role="tabpanel" aria-labelledby="v-pills-adherent-tab">
				<div class="card card-outline-secondary my-4">
				  <div class="card-header"> Details Adherant</div>
				  <div class="card-body">
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-adherent">
							<a class="nav-link active" data-toggle="tab" href="#detailsAdherentTab">Adherant</a>
						</li>
						
					</ul>
					
					<!-- Volets à onglets pour les détails des adhérents  -->
					<div class="tab-content">
						<div id="detailsAdherentTab" class="container-fluid tab-pane active">
							<br>
							<!-- Div pour afficher le message ajax de la soumission des validations/db -->
							<div id="messageDetailsAdherent"></div>
							<form>
							  <div class="form-row">
								<div class="form-group col-md-3" style="display:inline-block">
								  <label for="detailsAdherentImmatriculationAdherent">Immatriculation<span class="requiredIcon">*</span></label>
								  <input type="text" class="form-control" name="detailsAdherentImmatriculationAdherent" id="detailsAdherentImmatriculationAdherent" autocomplete="off">
								  <div id="detailsAdherentImmatriculationAdherentSuggestionsDiv" class="adherentListDivWidth"></div>
								</div>
								<div class="form-group col-md-3">
								  <label for="detailsAdherentIDAdherent">ID Adherant</label>
								  <input class="form-control invTooltip" type="number" readonly  id="detailsAdherentIDAdherent" name="detailsAdherentIDAdherent" title="ceci va generer le numéro à l'ajout d'un adherant">
								</div>
							  </div>
							  <div class="form-row">
								  <div class="form-group col-md-6">
									<label for="detailsAdherentNomAdherent"> Nom <span class="requiredIcon">*</span></label>
									<input type="text" class="form-control" name="detailsAdherentNomAdherent" id="detailsAdherentNomAdherent" autocomplete="off">
									<div id="detailsAdherentNomAdherentSuggestionsDiv" class="adherentListDivWidth"></div>
								  </div>
								  <div class="form-group col-md-2">
									<label for="detailsAdherentVilleAdherent">Ville</label>
									<select id="detailsAdherentVilleAdherent" name="detailsAdherentVilleAdherent" class="form-control chosenSelect">
										<?php include('connexions/villeList.html'); ?>
									</select>
								  </div>
							  </div>
							  <div class="form-row">
								  <div class="form-group col-md-6">
									<label for="detailsAdherentPrenomAdherent"> Prenoms <span class="requiredIcon">*</span></label>
									<input type="text" class="form-control" name="detailsAdherentPrenomAdherent" id="detailsAdherentPrenomAdherent" autocomplete="off">
								  </div>
								  <div class="form-group col-md-4">
									<label for="detailsAdherentCniAdherent">N° CNI/ATTESTATION/PASSPORT</label>
									<input id="detailsAdherentCniAdherent" name="detailsAdherentCniAdherent" class="form-control ">
								  </div>
							  </div>
							  <div class="form-row">
								  <div class="form-group col-md-6">
									<label for="detailsAdherentTelAdherent"> Telephone <span class="requiredIcon">*</span></label>
									<input type="text" class="form-control" title="Enlevez le premier zero svp" name="detailsAdherentTelAdherent" id="detailsAdherentTelAdherent" autocomplete="off">
								  </div>
								  <div class="form-group col-md-4">
									<label for="detailsAdherentQuartierAdherent">Village/Quartier</label>
									<input id="detailsAdherentQuartierAdherent" name="detailsAdherentQuartierAdherent" class="form-control ">
								  </div>
							  </div>
							  
							 
							  <button type="button" id="ajouterAdherent" class="btn btn-success">Ajouter Adherant</button>
							  <button type="button" id="boutonModifierDetailsAdherent" class="btn btn-primary">Modifier</button>
							  <button type="button" id="supprimerAdherent" class="btn btn-danger">Supprimer</button>
							  <button type="reset" class="btn" id="effacerAdherent">Effacer</button>
							</form>
						</div>
						
					</div>
				  </div> 
				</div>
			  </div>

			  
			  
			  <div class="tab-pane fade" id="v-pills-recherche" role="tabpanel" aria-labelledby="v-pills-recherche-tab">
				<div class="card card-outline-secondary my-4">
				  <div class="card-header">Recherche <button id="tableActualiserRecherche" name="tableActualiserRecherche" class="btn btn-warning float-right btn-sm">Actualiser</button></div>
				  <div class="card-body">										
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-adherent">
							<a class="nav-link active" data-toggle="tab" href="#rechercheAdherentTab">Adherant</a>
						</li>
					</ul>
  
					<!-- Volets d'onglet -->
					<div class="tab-content">
						<div id="rechercheAdherentTab" class="container-fluid tab-pane active">
						  <br>
						  <p>Utilisez la grille ci-dessous pour rechercher tous les détails des adhérants</p>
						  <!-- <a href="#" class="detailsAdherentHover" data-toggle="popover" id="10">wwwee</a> -->
							<div class="table-responsive" id="tableDetailsAdherentDiv"></div>
						</div>
						
					</div>
				  </div> 
				</div>
			  </div>
			  
		
			  </div>
			</div>
		 </div>
	  </div>
    </div>
<?php
	require 'connexions/piedpage.php';
?>
  </body>
</html>
