$(document).ready(function(){
	
	//S occuper du bouton enregistrer
	$('#enregistrer').on('click', function(){
		enregistrer();
	});
	
	//S occuper du bouton retablir mot de passe
	$('#boutonRetablirMdp').on('click', function(){
		retablirMdp();
	});
	
	//S occuper du bouton de connexion
	$('#connexion').on('click', function(){
		connexion();
	});
});


// Fonction pour enregistrer un nouveau utilisateur
function enregistrer(){
	var enregistrerNom = $('#enregistrerNom').val();
	var enregistrerPseudo = $('#enregistrerPseudo').val();
	var enregistrerMdp1 = $('#enregistrerMdp1').val();
	var enregistrerMdp2 = $('#enregistrerMdp2').val();
	
	$.ajax({
		url: 'entite/connexion/enregistrer.php',
		method: 'POST',
		data: {
			enregistrerNom:enregistrerNom,
			enregistrerPseudo:enregistrerPseudo,
			enregistrerMdp1:enregistrerMdp1,
			enregistrerMdp2:enregistrerMdp2,
		},
		success: function(data){
			$('#enregistrerMessage').html(data);
		}
	});
}


//Fonction pout retablir le mot de passe
function retablirMdp(){
	var retablirMdpPseudo = $('#retablirMdpPseudo').val();
	var retablirMdpMdp1 = $('#retablirMdpMdp1').val();
	var retablirMdpMdp2 = $('#retablirMdpMdp2').val();
	
	$.ajax({
		url: 'entite/connexion/retablirMdp.php',
		method: 'POST',
		data: {
			retablirMdpPseudo:retablirMdpPseudo,
			retablirMdpMdp1:retablirMdpMdp1,
			retablirMdpMdp2:retablirMdpMdp2,
		},
		success: function(data){
			$('#messageRetablirMdp').html(data);
		}
	});
}


// Fonction pour connecter un utilisateur
function connexion(){
	var connecterPseudo = $('#connecterPseudo').val();
	var connecterMdp = $('#connecterMdp').val();
	
	$.ajax({
		url: 'entite/connexion/verification.php',
		method: 'POST',
		data: {
			connecterPseudo:connecterPseudo,
			connecterMdp:connecterMdp,
		},
		success: function(data){
			$('#messageConnexion').html(data);
			
			if(data.indexOf('Redirecting') >= 0){
				window.location = 'index.php';
			}
		}
	});
}