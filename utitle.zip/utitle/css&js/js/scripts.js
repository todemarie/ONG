

// Fichier qui crée la table de recherche des détails de l'adhérent
fichCreationTableRechercheDetailsAdherent = 'entite/adherent/creationTableRechercheDetailsAdherent.php';  


// Fichier qui crée la table de recherche des rapports adhérents
fichCreationTableRechercheRapportAdherent = 'entite/adherent/creationTableRechercheRapportAdherent.php';


// Fichier qui renvoie le dernier IDAdherent inséré pour l'onglet des détails de l'adhérent
fichMontrerDernierIDAdherent = 'entite/adherent/montrerDernierIDAdherent.php';


// Fichier qui renvoie immatriculationAdherent
fichMontrerSugestionsImmatriculationAdherent = 'entite/adherent/voirImmatriculationAdherent.php';





// Fichier qui retourne nom Aadherent
fichVoirNomAdherent = 'entite/adherent/voirNomAdherent.php';


// Fichier qui deroule nom Aadherent
fichDerouleNomAdherent = 'entite/adherent/derouleNomAdherent.php';

// File that updates an image
updateImageFile = 'entite/image/modifierImage.php';

// File that deletes an image
deleteImageFile = 'entite/image/supprimerImage.php';



$(document).ready(function(){
	// Donnez un style aux listes déroulantes. Vous devez définir explicitement la largeur
     // afin de résoudre le problème de la liste déroulante non visible lorsque l'onglet est masqué
	$('.chosenSelect').chosen({ width: "95%"});
	
	// Lancer les info-bulles
	$('.invTooltip').tooltip(); 
	

	
// Écouter le bouton d'ajout de l'adhérent
	$('#ajouterAdherent').on('click', function(){
		ajouterAdherent();
	});
	
	
	// Écouter le bouton de mise à jour dans l'onglet des détails de l'adhérent
	$('#boutonModifierDetailsAdherent').on('click', function(){
		modifierAdherent();
	});
	
	
	
	// Écouter le bouton de suppression dans l'onglet des détails de l'adhérent
	$('#supprimerAdherent').on('click', function(){
		// Confirm before deleting
		bootbox.confirm('Etes-vous sûr de vouloir supprimer?', function(result){
			if(result){
				supprimerAdherent();
			}
		});
	});
	
	
	
	// Écouter la zone de texte du nom de l'adhérent dans l'onglet des détails de l'adhérent
	$('#detailsAdherentNomAdherent').keyup(function(){
		voirSugestions('detailsAdherentNomAdherent', fichVoirNomAdherent, 'detailsAdherentNomAdherentSuggestionsDiv');
	});
	
	// Supprime la liste déroulante des suggestions de noms d'adhérents dans l'onglet Détails de l'adhérent
// lorsque l'utilisateur sélectionne un adhérent à partir de celui-ci
	$(document).on('click', '#detailsAdherentNomAdherentsSuggestionsList li', function(){
		$('#detailsAdherentNomAdherent').val($(this).text());
		$('#detailsAdherentNomAdherentsSuggestionsList').fadeOut();
	});
	
	// Écoutez la zone de texte du numéro d'adhérent dans l'onglet Détails de l'adhérent
	$('#detailsAdherentImmatriculationAdherent').keyup(function(){
		voirSugestions('detailsAdherentImmatriculationAdherent', fichMontrerSugestionsImmatriculationAdherent, 'detailsAdherentImmatriculationAdherentSuggestionsDiv');
	});
	
	// Supprimer la liste déroulante des suggestions de numéros d'adhérent dans l'onglet des détails de l'adhérent
// lorsque l'utilisateur sélectionne un adhérent à partir de celui-ci
	$(document).on('click', '#detailsAdherentImmatriculationAdherentSuggestionsList li', function(){
		$('#detailsAdherentImmatriculationAdherent').val($(this).text());
		$('#detailsAdherentImmatriculationAdherentSuggestionsList').fadeOut();
		derouleDetailsAdherentToPopulate();
	});
	
	
	
	// Lancement des sélecteurs de date
	$('.datepicker').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		todayBtn: 'linked',
		orientation: 'bottom left'
	});
	
	// Ferme toutes les listes de suggestions de la page lorsqu'un utilisateur clique sur la page
	$(document).on('click', function(){
		$('.suggestionsList').fadeOut();
	});

	// Charger les tables de données searchTable pour l'adhérent
	creationTableRecherche('tableDetailsAdherentDiv', fichCreationTableRechercheDetailsAdherent, 'tableDetailsAdherent');
	
	// Charger les tables de données searchTable pour l'adhérent
	creationTableRapport('tableRpportAdherentDiv', fichCreationTableRechercheRapportAdherent, 'tableRpportAdherent');
	
	// Initier des popovers
	$(document).on('mouseover', '.detailsAdherentHover', function(){
		// Créer des boîtes popover de détails adhérents
		$('.detailsAdherentHover').popover({
			container: 'body',
			title: ' Details Adherent',
			trigger: 'hover',
			html: true,
			placement: 'right',
			content: fetchData
		});
	});
	
	// Listen to refresh buttons
	$('#tableActualiserRecherche, #tableActualiserRapport').on('click', function(){
		creationTableRecherche('tableDetailsAdherentDiv', fichCreationTableRechercheDetailsAdherent, 'tableDetailsAdherent');
		
		creationTableRapport('tableRpportAdherentDiv', fichCreationTableRechercheRapportAdherent, 'tableRpportAdherent');
	});
	
});


// Fonction pour récupérer les données à afficher dans les popovers
function fetchData(){
	var fetch_data = '';
	var element = $(this);
	var id = element.attr('id');
	
	$.ajax({
		url: 'entite/adherent/derouleDetailsAdherentForPopover.php',
		method: 'POST',
		async: false,
		data: {id:id},
		success: function(data){
			fetch_data = data;
		}
	});
	return fetch_data;
}


// Fonction pour créer des tables de données searchTable pour l'adhérent
function creationTableRecherche(tableContainerDiv, tableCreatorFileUrl, table){
	var tableContainerDivID = '#' + tableContainerDiv;
	var tableID = '#' + table;
	$(tableContainerDivID).load(tableCreatorFileUrl, function(){
		// Lancer le plugin Datatable une fois la table ajoutée au DOM
		$(tableID).DataTable();
	});
}


/// Fonction pour créer des tables de données de rapports pour l'élément
function creationTableRapport(tableContainerDiv, tableCreatorFileUrl, table){
	var tableContainerDivID = '#' + tableContainerDiv;
	var tableID = '#' + table;
	$(tableContainerDivID).load(tableCreatorFileUrl, function(){
		// Lancer le plugin Datatable une fois la table ajoutée au DOM
		$(tableID).DataTable({
			dom: 'lBfrtip',
			//dom: 'lfBrtip',
			//dom: 'Bfrtip',
			buttons: [
				'copy',
				'csv', 'excel',
				{extend: 'pdf', orientation: 'landscape', pageSize: 'LEGAL'},
				'print'
			]
		});
	});
}


// Fonction pour appeler le script inserterAdherent.php pour insérer les données adhérentes dans la base de données
function ajouterAdherent() {
	var detailsAdherentImmatriculationAdherent = $('#detailsAdherentImmatriculationAdherent').val();
	var detailsAdherentNomAdherent = $('#detailsAdherentNomAdherent').val();
	var detailsAdherentVilleAdherent = $('#detailsAdherentVilleAdherent option:selected').text();
	var detailsAdherentPrenomAdherent = $('#detailsAdherentPrenomAdherent').val();
	var detailsAdherentCniAdherent=$('#detailsAdherentCniAdherent').val();
	var detailsAdherentTelAdherent=$('#detailsAdherentTelAdherent').val();
	var detailsAdherentQuartierAdherent=$('#detailsAdherentQuartierAdherent').val();

	
	$.ajax({
		url: 'entite/adherent/insererAdherent.php',
		method: 'POST',
		data: {
			detailsAdherentImmatriculationAdherent:detailsAdherentImmatriculationAdherent,
			detailsAdherentNomAdherent:detailsAdherentNomAdherent,
			detailsAdherentVilleAdherent:detailsAdherentVilleAdherent,
			detailsAdherentPrenomAdherent:detailsAdherentPrenomAdherent,
			detailsAdherentCniAdherent:detailsAdherentCniAdherent,
			detailsAdherentTelAdherent:detailsAdherentTelAdherent,
			detailsAdherentQuartierAdherent:detailsAdherentQuartierAdherent,
			
			
		},
		success: function(data){
			$('#messageDetailsAdherent').fadeIn();
			$('#messageDetailsAdherent').html(data);
		},
		complete: function(){
			montrerDernierIDAdherent(fichMontrerDernierIDAdherent, 'detailsAdherentIDAdherent');
			creationTableRecherche('tableDetailsAdherentDiv', fichCreationTableRechercheDetailsAdherent, 'tableDetailsAdherent');
			creationTableRapport('tableRpportAdherentDiv', fichCreationTableRechercheRapportAdherent, 'tableRpportAdherent');
		}
	});
}



// Fonction pour envoyer immatriculationAdherent afin que les détails de l'adhérent puissent être extraits de la base de données
// à afficher sur l'onglet des détails de l'adhérent
function derouleDetailsAdherentToPopulate(){
	// Obtenez l'immatriculation Adhérent entré dans la zone de texte
	var immatriculationAdherent = $('#detailsAdherentImmatriculationAdherent').val();
	
	// Appel du script montrerDetailsAdherent.php pour obtenir les détails de l'adhérent
// correspondant à l'immatriculationAdhérent que l'utilisateur a saisi
	$.ajax({
		url: 'entite/adherent/montrerDetailsAdherent.php',
		method: 'POST',
		data: {immatriculationAdherent:immatriculationAdherent},
		dataType: 'json',
		success: function(data){
			//$('#detailsAdherentImmatriculationAdherent').val(data.immatriculationAdherent);
			$('#detailsAdherentIDAdherent').val(data.IDAdherent);
			$('#detailsAdherentNomAdherent').val(data.nomAdherent);
			$('#detailsAdherentVilleAdherent').val(data.villeAdherent).trigger("chosen:updated");
			$('#detailsAdherentPrenomAdherent').val(data.prenomAdherent);
			$('#detailsAdherentCniAdherent').val(data.cniAdherent);
			$('#detailsAdherentTelAdherent').val(data.telAdherent);
			$('#detailsAdherentQuartierAdherent').val(data.quartierAdherent);

			
		}
	});
}


// Fonction pour envoyer immatriculationAdherent afin que le nom de l'adhérent puisse être extrait de la base de données
function derouleNomAdherent(immatriculationAdherentTextBoxID, scriptPath, nomAdherentTextbox){
	// Get the immatriculationAdherent entered in the text box
	var immatriculationAdherent = $('#' + immatriculationAdherentTextBoxID).val();

	// Call the script to get adherent details
	$.ajax({
		url: scriptPath,
		method: 'POST',
		data: {immatriculationAdherent:immatriculationAdherent},
		dataType: 'json',
		success: function(data){
			$('#' + nomAdherentTextbox).val(data.nomAdherent);
		},
		error: function (xhr, ajaxOptions, thrownError) {
      }
	});
}


// Fonction pour envoyer immatriculationAdherent afin que le stock adhérent puisse être extrait de la base de données
function getadherentStockToPopulate(immatriculationAdherentTextbox, scriptPath, stockTextbox){
	// Obtenez l'immatriculation Adhérent entré dans la zone de texte
	var immatriculationAdherent = $('#' + immatriculationAdherentTextbox).val();
	
	// Appelez le script pour obtenir les détails du stock
	$.ajax({
		url: scriptPath,
		method: 'POST',
		data: {immatriculationAdherent:immatriculationAdherent},
		dataType: 'json',
		success: function(data){
			$('#' + stockTextbox).val(data.stock);
		},
		error: function (xhr, ajaxOptions, thrownError) {
        //alert(xhr.ville);
        //alert(thrownError);
		//console.warn(xhr.responseText)
      }
	});
}


// Fonction pour remplir le dernier ID inséré
function montrerDernierIDAdherent(scriptPath, textBoxID){
	$.ajax({
		url: scriptPath,
		method: 'POST',
		dataType: 'json',
		success: function(data){
			$('#' + textBoxID).val(data);
		}
	});
}


// Fonction pour afficher des suggestions
function voirSugestions(textBoxID, scriptPath, suggestionsDivID){
	// Obtenir la valeur saisie par l'utilisateur
	var textBoxValue = $('#' + textBoxID).val();
	
	// Call the showPurchaseIDs.php script only if there is a value in the
	// purchase ID textbox
	if(textBoxValue != ''){
		$.ajax({
			url: scriptPath,
			method: 'POST',
			data: {textBoxValue:textBoxValue},
			success: function(data){
				$('#' + suggestionsDivID).fadeIn();
				$('#' + suggestionsDivID).html(data);
			}
		});
	}
}


// Fonction pour supprimer l'adhérent de la base de données
function supprimerAdherent(){
	//Obtenir le numéro d'adhérent saisi par l'utilisateur
	var detailsAdherentImmatriculationAdherent = $('#detailsAdherentImmatriculationAdherent').val();
	
	// Appel du script supprimerAdherent.php uniquement s'il y a une valeur dans le
// zone de texte du numéro d'adhérent
	if(detailsAdherentImmatriculationAdherent != ''){
		$.ajax({
			url: 'entite/adherent/supprimerAdherent.php',
			method: 'POST',
			data: {detailsAdherentImmatriculationAdherent:detailsAdherentImmatriculationAdherent},
			success: function(data){
				$('#messageDetailsAdherent').fadeIn();
				$('#messageDetailsAdherent').html(data);
			},
			complete: function(){
				creationTableRecherche('tableDetailsAdherentDiv', fichCreationTableRechercheDetailsAdherent, 'tableDetailsAdherent');
				creationTableRapport('tableRpportAdherentDiv', fichCreationTableRechercheRapportAdherent, 'tableRpportAdherent');
			}
		});
	}
}

// Fonction pour appeler le script upateadherentDetails.php pour METTRE À JOUR les données adhérentes dans la base de données
function modifierAdherent() {
	var detailsAdherentImmatriculationAdherent = $('#detailsAdherentImmatriculationAdherent').val();
	var detailsAdherentNomAdherent = $('#detailsAdherentNomAdherent').val();
	var detailsAdherentVilleAdherent = $('#detailsAdherentVilleAdherent option:selected').text();
	var detailsAdherentPrenomAdherent = $('#detailsAdherentPrenomAdherent').val();
	var detailsAdherentCniAdherent=$('#detailsAdherentCniAdherent').val();
	var detailsAdherentTelAdherent=$('#detailsAdherentTelAdherent').val();
	var detailsAdherentQuartierAdherent=$('#detailsAdherentQuartierAdherent').val();
	
	$.ajax({
		url: 'entite/adherent/modifierDetailsAdherent.php',
		method: 'POST',
		data: {
			detailsAdherentImmatriculationAdherent:detailsAdherentImmatriculationAdherent,
			detailsAdherentNomAdherent:detailsAdherentNomAdherent,
			detailsAdherentVilleAdherent:detailsAdherentVilleAdherent,
			detailsAdherentPrenomAdherent:detailsAdherentPrenomAdherent,
			detailsAdherentCniAdherent:detailsAdherentCniAdherent,
			detailsAdherentTelAdherent:detailsAdherentTelAdherent,
			detailsAdherentQuartierAdherent,detailsAdherentQuartierAdherent,
		},
		success: function(data){
				$('#messageDetailsAdherent').fadeIn();
				$('#messageDetailsAdherent').html(data);
			
		},
		complete: function(){
			creationTableRecherche('tableDetailsAdherentDiv', fichCreationTableRechercheDetailsAdherent, 'tableDetailsAdherent');
			creationTableRapport('tableRpportAdherentDiv', fichCreationTableRechercheRapportAdherent,'tableRpportAdherent');			
		}
	});
}



